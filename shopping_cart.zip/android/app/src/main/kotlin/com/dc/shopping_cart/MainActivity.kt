package com.dc.shopping_cart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
